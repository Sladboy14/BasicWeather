# Simple Kotlin Apps : BasicWeather
Selamat datang di BasicWeather, aplikasi cuaca sederhana yang dibangun menggunakan bahasa pemrograman Kotlin. Aplikasi ini dirancang untuk memberikan informasi cuaca yang mudah dipahami dan cepat diakses.

#### Features
Informasi Cuaca Terkini:

Dapatkan pembaruan cuaca terkini di lokasi Anda secara langsung.
Tampilkan suhu saat ini, kelembaban, kecepatan angin, dan kondisi cuaca umum.